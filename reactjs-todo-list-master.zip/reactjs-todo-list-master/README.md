# reactjs-todo-list
This is a todo list created with reactjs from a youtube tutorial: https://youtu.be/iZ8RZqkZj14

1 - run "npm install"

2 - run "npm start"
